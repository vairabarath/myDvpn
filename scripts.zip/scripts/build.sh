#!/bin/bash

# Simple build verification script

echo "=== Building myDvpn Unified Client System ==="

cd /mnt/EDU/myDvpn

# Clean previous builds
rm -rf bin/
mkdir -p bin

echo "Building BaseNode..."
go build -o bin/basenode ./cmd/basenode
echo "✓ BaseNode built successfully"

echo "Building SuperNode..."
go build -o bin/supernode ./cmd/supernode
echo "✓ SuperNode built successfully"

echo "Building Unified Client..."
go build -o bin/unified-client ./cmd/unified-client
echo "✓ Unified Client built successfully"

echo "Building Legacy Client (for compatibility)..."
go build -o bin/client ./cmd/client
echo "✓ Legacy Client built successfully"

echo "Building Legacy Exit Peer (for compatibility)..."
go build -o bin/exitpeer ./cmd/exitpeer
echo "✓ Legacy Exit Peer built successfully"

echo ""
echo "=== Build Summary ==="
ls -la bin/
echo ""

echo "=== Component Versions ==="
./bin/basenode --help 2>&1 | head -3 || echo "BaseNode help output"
./bin/supernode --help 2>&1 | head -3 || echo "SuperNode help output"
./bin/unified-client --help 2>&1 | head -3 || echo "Unified Client help output"

echo ""
echo "=== All components built successfully! ==="
echo ""
echo "🌟 NEW: Unified Client Application 🌟"
echo "  - Single application that can act as both client and exit peer"
echo "  - Toggle between modes with 'toggle-exit on/off'"
echo "  - Interactive UI for easy management"
echo ""
echo "To test the unified system:"
echo "  ./scripts/test.sh              # Start full system"
echo "  ./bin/unified-client           # Start interactive client"
echo ""
echo "To start a peer manually:"
echo "  ./bin/unified-client --id=my-peer --region=us-east-1 --supernode=localhost:50052"
echo ""
echo "Then in the UI:"
echo "  > toggle-exit on               # Become an exit peer"
echo "  > connect us-west-1            # Connect to exit in us-west-1"
echo "  > status                       # Check current status"
echo "  > help                         # See all commands"